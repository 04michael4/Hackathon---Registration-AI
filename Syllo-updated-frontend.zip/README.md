# Syllo frontend

Open `dist/index.html` in a modern browser. No build, installation, credentials, or backend is required. Keep all files in `dist` together.

## Try the connected experience

1. Use Sign in with Lehigh SSO. This is a clearly labeled demo entry, not a real SSO connection. It collects no credentials. The original four-card start page opens; the four navigation tabs appear only after entering a planning area. The top role button still lets you try the advisor demo.
2. Plan next semester: search courses, drag an eligible result or recommendation onto the calendar, or use its Add button. Calendar blocks keep the course's actual demo section time. Right-click one for course details and professor ratings.
3. Open Syllo AI, choose recommended courses and time/day/professor/credit preferences, then preview the proposed schedule. Review exceptions and conflicts before applying it.
4. Save a named schedule and reopen it from Saved schedules. Undo restores the last planning change; Ctrl+Z / Command+Z works outside text fields.
5. Plan your degree: required future courses are prefilled; completed semesters are read-only. Moving courses checks prerequisite order and term offerings. Click blank elective slots to search and choose matching courses. Use the next-semester calendar and degree-plan exchange buttons to carry courses between the two views.
6. Fill the two elective slots to complete the demo graduation plan, then send it for review. Student access to the full advisor review opens after the graduation checks pass. The advisor demo can access the plan anytime.
7. Switch to the advisor demo with the role button. Post a comment on the whole plan or a course, request changes, or approve a submitted valid plan. Return to the student role to see alerts and feedback.

## Data and persistence

The catalog, professors, ratings, registration date, transcript, curriculum and prerequisite rules are simulated. They are not the official Lehigh catalog, a real degree audit, or live registration availability. The assistant uses local planning rules; it does not call an AI service. The mock login collects no account information. Advisor roles are a demonstration, not an access-control boundary.

Plans, saved schedules, chat drafts and advisor feedback use browser local storage. They stay in that browser/profile and do not sync to other people or devices. Undo history lasts for the current page session. Browser storage must be enabled to retain changes after closing the page.

## Backend handoff

- `dist/data.js`: catalog and transcript boundary, shared state, prerequisite/term checks, degree audit, save and undo. Replace the demo catalog/transcript and local persistence with authenticated backend APIs here.
- `dist/semester.js`: search, calendar, recommendations, conflict choices and planning assistant UI.
- `dist/degree.js`: four-year plan, elective selection, submission and advisor feedback.
- `dist/app.js`: navigation, shared course details, saved-schedule library and role demonstration.
- `dist/polish.js`: interest matching, integrated prerequisite highlighting, degree workspace tabs, and advisor multi-status filters. Reuses the existing course drawer, course-add/conflict flow, degree search and shared store.
- `dist/polish.css`: shared brown/white/gold theme tokens and compact laptop workspace. Retained styles and course colors reference these tokens rather than maintaining separate palettes.
- `dist/styles.css`: retained original styling; `product.css`, `semester.css`, `degree.css`: integrated additions.

Before real deployment, connect server-enforced roles, authoritative curriculum/section data, durable student/advisor records, actual registration dates, and the intended AI service. No secrets belong in this static frontend.

## Highlighted UI refinements

- Degree course details reserve a 320px panel on the right for screens at least 760px wide. The planner resizes to the left rather than being covered; narrower laptop/tablet views reflow to four semester columns while details are open. Closing the panel restores the full-width eight-column laptop view and clears prerequisite focus. On small phones the same course details stack below the planner instead of overlaying courses. Course selection and keyboard navigation remain available while the non-modal panel is open.

- Every entry into the degree planner defaults to all four years/eight semesters, even if an older saved view hid semesters. View toggles still work during that visit. Course cards have no six-dot handles or semester dropdowns; drag the card itself to move it. Completed courses and semesters remain locked.

- The Degree calendar fits all eight semester columns across laptop widths without horizontal scrolling or zoom. Smaller screens wrap semesters into four or two columns so text remains readable. The next semester is highlighted; completed semesters stay locked. Course details, credits and drag-and-drop remain connected to the existing model. Per-course semester dropdowns have been removed from regular and elective cards; move courses by dragging. Year/semester visibility controls, elective selection and the AI tab are retained. Page scrolling stays enabled.

- Normal page scrolling is enabled on desktop and mobile so all course lists and planning controls remain reachable. Course cards stay compact. The expanded weekly calendar retains its own scrollable view. Degree workspace tabs separate the calendar and assistant; there is no separate prerequisite-map tab.
- Recommended course cards show a compact code/title and one Add button. Adding a course places it on the calendar and includes it in AI planning; the button becomes Added. Remove it from Planned classes to clear that selection. There is no separate AI checkbox. Hover or open the existing drawer for credits, requirements, meeting times and prerequisites. Calendar courses remain non-draggable; eligible search/recommended cards can still be dragged into the calendar. Degree courses can move between future terms, with completed terms locked.
- Search by interest is separate from course-code search in both planners. Keyword/alias matching is centralized in `SylloPolish.searchInterest`, prioritizes electives and uses the current demo catalog. Semester results obey existing prerequisite, offering and conflict rules. Degree results reuse the target-semester course search and elective-slot logic.
- Click a degree-calendar course to open its details and highlight related courses using the existing catalog prerequisite arrays. The selected course uses yellow, prerequisite courses use blue, and follow-on courses use green, all with dark text and a labeled color legend. A 60% black tint darkens the surrounding screen. Highlighted cards, the Clear selection control and course details remain bright. This tint does not intercept clicks or scrolling. Escape, the drawer close button, Clear selection, blank calendar space, or clicking the selected card resets the spotlight. CSE 340 is absent from this catalog; no example course relationship was invented.
- Advisor course filters allow All, Done, Review, Withdraw and Planned, with multiple selection and an empty state. Done comes from completed coursework; Review reflects course feedback/submitted plans. An advisor can save a demo Review/Withdraw/Planned label. These labels do not withdraw a registration, alter completed coursework or waive graduation requirements. Changes generate existing student notifications.
- Existing recommended-course choices, time/day/professor/credit preferences, explained AI previews, user-selected conflict resolution and prerequisite preview-only behavior are preserved.

Verification: 24 browser workflow/layout checks passed, plus native degree drag/drop, prerequisite rejection, completed-term locks, elective credit accounting and undo. No browser JavaScript errors. SSO, AI replies, academic data, professor ratings and collaboration remain browser-local demonstrations, not live university integrations.
