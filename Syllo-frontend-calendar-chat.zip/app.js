const screens = [...document.querySelectorAll('[data-screen]')];
const navLinks = [...document.querySelectorAll('[data-nav]')];
let onboardingStep = 1;
let activeSchedule = 'balanced';
let locked = new Set(['cse241']);
let plannerCourses = new Set(['cse241','math231']);
let plannerPreviewId = null;
const requiredPlannerCourses = ['cse241','math231','ds210','cse252'];
let contextCalendarCourse = null;

const courses = {
  cse241:{code:'CSE 241',name:'Data Structures & Algorithms',section:'010 · Prof. Maya Chen',days:'Mon / Wed',time:'9:10–10:25 AM',credits:4,color:'#5a2d0c',bg:'#f2e8df',requirement:'CS Major Core',difficulty:'3.7 / 5',workload:'8–10 hrs/wk',rating:'4.6'},
  math231:{code:'MATH 231',name:'Probability & Statistics',section:'020 · Prof. Daniel Park',days:'Tue / Thu',time:'10:45 AM–12:00 PM',credits:4,color:'#b88920',bg:'#fff4cf',requirement:'Data Science Minor',difficulty:'3.3 / 5',workload:'6–8 hrs/wk',rating:'4.3'},
  ds210:{code:'DS 210',name:'Data Systems',section:'010 · Prof. Elena Ruiz',days:'Tue / Thu',time:'1:10–2:25 PM',credits:3,color:'#8b634b',bg:'#f4eee9',requirement:'Data Science Minor',difficulty:'3.9 / 5',workload:'8–11 hrs/wk',rating:'4.8'},
  phil114:{code:'PHIL 114',name:'Ethics of Technology',section:'011 · Prof. Samira Cole',days:'Mon / Wed',time:'11:15 AM–12:05 PM',credits:3,color:'#7b4327',bg:'#f6eae3',requirement:'Humanities Elective',difficulty:'2.4 / 5',workload:'3–5 hrs/wk',rating:'4.5'},
  cse252:{code:'CSE 252',name:'Computer Networks Lab',section:'013 · Prof. Jordan Lee',days:'Thursday',time:'2:35–4:25 PM',credits:1,color:'#c3a451',bg:'#faf3dc',requirement:'CS Major Core',difficulty:'3.1 / 5',workload:'3–4 hrs/wk',rating:'4.2'}
};

const schedules = {
  balanced:[
    ['cse241',1,'14%','16%'],['cse241',3,'14%','16%'],['math231',2,'34%','15%'],['math231',4,'34%','15%'],
    ['phil114',1,'41%','11%'],['phil114',3,'41%','11%'],['ds210',2,'64%','16%'],['ds210',4,'64%','16%'],['cse252',4,'82%','17%']
  ],
  focused:[
    ['cse241',1,'8%','16%'],['cse241',3,'8%','16%'],['math231',2,'22%','15%'],['math231',4,'22%','15%'],
    ['phil114',1,'31%','11%'],['phil114',3,'31%','11%'],['ds210',2,'62%','16%'],['ds210',4,'62%','16%'],['cse252',4,'80%','17%']
  ],
  compact:[
    ['cse241',1,'14%','16%'],['cse241',3,'14%','16%'],['math231',1,'34%','15%'],['math231',3,'34%','15%'],
    ['phil114',1,'64%','11%'],['phil114',3,'64%','11%'],['ds210',2,'64%','16%'],['ds210',4,'64%','16%']
  ]
};

const semesterOrder = ['spring-2027','fall-2027','spring-2028','fall-2028'];
const semesterLabels = {'spring-2027':'Spring 2027','fall-2027':'Fall 2027','spring-2028':'Spring 2028','fall-2028':'Fall 2028'};
const degreeSemesters = {'spring-2027':['cse241','math231','ds210'],'fall-2027':['cse252'],'spring-2028':[],'fall-2028':[]};
const requirementDetails = {
  general:{title:'Core curriculum',status:'Completed',copy:'The demo degree record shows all 12 core curriculum requirements complete.',courses:[]},
  major:{title:'CS major core',status:'In progress',copy:'The demo record shows 8 of 12 major requirements complete. The available catalog records below are tagged to this area.',courses:['cse241','cse252']},
  minor:{title:'Data Science minor',status:'Planned',copy:'The demo record shows 3 of 6 minor requirements complete. These available records are tagged to the minor.',courses:['math231','ds210']},
  electives:{title:'Free electives',status:'Remaining',copy:'Two elective courses remain in the demo degree record. Only one matching elective is available in the prototype catalog.',courses:['phil114']}
};

function showScreen(name){
  screens.forEach(s=>s.classList.toggle('active',s.dataset.screen===name));
  document.body.classList.toggle('welcome-only',name==='welcome'||name==='login');
  navLinks.forEach(n=>n.classList.toggle('active',(name==='requirements'&&n.dataset.nav==='requirements')||(name!=='requirements'&&n.dataset.nav==='plan')));
  if(name==='planner'){renderPlannerSearch();renderManualSchedule();renderSuggestions()}
  if(name==='requirements'){renderRequirementDetail('general');renderElectives();renderDegreeSemesters()}
  window.scrollTo({top:0,behavior:'smooth'});
}

function setOnboardingStep(step){
  onboardingStep=Math.max(1,Math.min(3,step));
  document.querySelectorAll('[data-onboarding-step]').forEach(c=>c.classList.toggle('hidden',Number(c.dataset.onboardingStep)!==onboardingStep));
  document.querySelectorAll('[data-step-indicator]').forEach(ind=>{
    const n=Number(ind.dataset.stepIndicator); ind.classList.toggle('active',n===onboardingStep); ind.classList.toggle('complete',n<onboardingStep);
    ind.querySelector('span').textContent=n<onboardingStep?'✓':n;
  });
}

function renderCourses(){
  const list=document.getElementById('course-list');
  list.innerHTML=Object.entries(courses).map(([id,c])=>`<article class="course-item" data-course="${id}" tabindex="0"><span class="color" style="background:${c.color}"></span><div><strong>${c.code} · ${c.name}</strong><small>${c.days} · ${c.credits} credits</small></div><button aria-label="${locked.has(id)?'Unlock':'Lock'} ${c.code}">${locked.has(id)?'●':'○'}</button></article>`).join('');
  list.querySelectorAll('.course-item').forEach(el=>{el.addEventListener('click',()=>openDrawer(el.dataset.course));el.addEventListener('keydown',e=>{if(e.key==='Enter')openDrawer(el.dataset.course)})});
}

function renderCalendar(){
  const holder=document.getElementById('calendar-events');
  holder.innerHTML=schedules[activeSchedule].map(([id,day,top,height])=>{const c=courses[id];return `<article class="calendar-event" style="--day:${day};--top:${top};--height:${height};--event-color:${c.color};--event-bg:${c.bg}" data-course="${id}" tabindex="0"><strong>${c.code}</strong><small>${c.name}</small>${locked.has(id)?'<span class="event-lock">●</span>':''}</article>`}).join('');
  holder.querySelectorAll('.calendar-event').forEach(el=>{el.addEventListener('click',()=>openDrawer(el.dataset.course));el.addEventListener('keydown',e=>{if(e.key==='Enter')openDrawer(el.dataset.course)})});
}

function instructorName(course){return course.section.split('·')[1]?.trim()||'Not available'}
function sectionNumber(course){return course.section.split('·')[0]?.trim()||'Not available'}
function courseDays(course){return course.days.split('/').map(day=>day.trim().slice(0,3))}
function timeValue(raw,fallbackMeridiem){
  const match=raw.trim().match(/(\d+):(\d+)\s*(AM|PM)?/i); if(!match)return null;
  let hour=Number(match[1]),minute=Number(match[2]); const meridiem=(match[3]||fallbackMeridiem||'AM').toUpperCase();
  if(meridiem==='PM'&&hour!==12)hour+=12;if(meridiem==='AM'&&hour===12)hour=0;return hour*60+minute;
}
function courseInterval(course){
  const parts=course.time.split('–'); if(parts.length!==2)return null;
  const endMeridiem=parts[1].match(/(AM|PM)/i)?.[1];
  const start=timeValue(parts[0],endMeridiem),end=timeValue(parts[1],endMeridiem);return start===null||end===null?null:[start,end];
}
function coursesConflict(firstId,secondId){
  const first=courses[firstId],second=courses[secondId];
  if(!courseDays(first).some(day=>courseDays(second).includes(day)))return false;
  const a=courseInterval(first),b=courseInterval(second);return Boolean(a&&b&&a[0]<b[1]&&b[0]<a[1]);
}
function conflictsFor(id){return [...plannerCourses].filter(other=>other!==id&&coursesConflict(id,other))}
function renderPlannerSearch(query=document.getElementById('course-search')?.value||''){
  const holder=document.getElementById('course-search-results');if(!holder)return;
  const term=query.trim().toLowerCase();
  const matches=Object.entries(courses).filter(([,c])=>[c.code,c.name,c.requirement,c.section,c.code.split(' ')[0]].join(' ').toLowerCase().includes(term));
  holder.innerHTML=matches.length?matches.map(([id,c])=>{
    const added=plannerCourses.has(id),conflicts=conflictsFor(id);
    return `<article class="search-result" draggable="true" data-drag-course="${id}"><div class="search-result-main"><div><span>${c.code}</span><strong>${c.name}</strong><small>${c.credits} credits · ${c.days} · ${c.time}</small></div><button class="button ${added?'quiet':'primary'}" data-action="add-planner-course" data-course="${id}" ${added?'disabled':''}>${added?'Added':'Add to Schedule'}</button></div>${conflicts.length?`<p class="course-warning conflict">Conflicts with ${conflicts.map(key=>courses[key].code).join(', ')}</p>`:''}<details><summary>Course details</summary><div class="search-detail-grid"><div><span>Description</span><strong>Not available in demo data</strong></div><div><span>Credits</span><strong>${c.credits}</strong></div><div><span>Prerequisites</span><strong>Not available in demo data</strong></div><div><span>Requirement area</span><strong>${c.requirement}</strong></div><div><span>Demo section</span><strong>${sectionNumber(c)}</strong></div><div><span>Instructor</span><strong>${instructorName(c)}</strong></div><div><span>Meeting time</span><strong>${c.days} · ${c.time}</strong></div><div><span>Availability</span><strong>Live availability not provided</strong></div></div></details></article>`
  }).join(''):'<div class="empty-state">No matching demo courses found.</div>';
}
function setCourseSearchOpen(open){
  const results=document.getElementById('course-search-results'),input=document.getElementById('course-search');if(!results||!input)return;
  results.classList.toggle('is-open',open);input.setAttribute('aria-expanded',String(open));
}
function formatPlannerTime(minutes){
  const hour24=Math.floor(minutes/60),minute=minutes%60,period=hour24>=12?'PM':'AM',hour=hour24%12||12;return `${hour}:${String(minute).padStart(2,'0')} ${period}`;
}
function closeCalendarContextMenu(){document.getElementById('calendar-context-menu')?.classList.add('hidden');contextCalendarCourse=null}
function openCalendarContextMenu(event,courseId){
  event.preventDefault();const menu=document.getElementById('calendar-context-menu');if(!menu)return;
  contextCalendarCourse=courseId;menu.classList.remove('hidden');
  const width=210,height=120;menu.style.left=`${Math.min(event.clientX,window.innerWidth-width-12)}px`;menu.style.top=`${Math.min(event.clientY,window.innerHeight-height-12)}px`;
}
function renderPlannerCourseSidebar(){
  const required=document.getElementById('required-course-list'),planned=document.getElementById('planned-course-list');if(!required||!planned)return;
  document.getElementById('required-course-count').textContent=requiredPlannerCourses.length;
  document.getElementById('planned-course-count').textContent=plannerCourses.size;
  required.innerHTML=requiredPlannerCourses.map(id=>{const c=courses[id],isPlanned=plannerCourses.has(id);return `<article class="planner-sidebar-course"><span class="sidebar-course-color" style="background:${c.color}"></span><div><strong>${c.code}</strong><span>${c.name}</span><small>${c.requirement} · ${c.credits} credits</small></div>${isPlanned?'<em>Planned</em>':`<button data-action="add-planner-course" data-course="${id}" aria-label="Add ${c.code}">+</button>`}</article>`}).join('');
  planned.innerHTML=plannerCourses.size?[...plannerCourses].map(id=>{const c=courses[id];return `<article class="planner-sidebar-course planned"><span class="sidebar-course-color" style="background:${c.color}"></span><div><strong>${c.code}</strong><span>${c.name}</span><small>${c.days} · ${c.time}</small></div><button data-action="remove-planner-course" data-course="${id}" aria-label="Remove ${c.code}">×</button></article>`}).join(''):'<div class="sidebar-empty">No classes planned yet.</div>';
}
function renderManualSchedule(){
  const holder=document.getElementById('planner-calendar-events');if(!holder)return;
  const ids=[...plannerCourses],credits=ids.reduce((sum,id)=>sum+courses[id].credits,0);
  document.getElementById('planner-credit-total').textContent=credits;
  const dayIndex={Mon:1,Tue:2,Wed:3,Thu:4,Fri:5};
  holder.innerHTML=ids.length?ids.flatMap(id=>{
    const c=courses[id],interval=courseInterval(c),conflicts=conflictsFor(id);if(!interval)return[];
    const duration=interval[1]-interval[0];
    const top=Math.max(0,Math.min(100,((interval[0]-480)/540)*100)),height=Math.max(5,Math.min(100-top,(duration/540)*100));
    return courseDays(c).filter(day=>dayIndex[day]).map(day=>`<article class="planner-calendar-event ${conflicts.length?'has-conflict':''}" style="--day:${dayIndex[day]};--top:${top}%;--height:${height}%;--event-color:${c.color};--event-bg:${c.bg}" data-course="${id}" tabindex="0" aria-label="${c.code}, ${day}, ${formatPlannerTime(interval[0])} to ${formatPlannerTime(interval[1])}" title="Right-click for options"><button data-action="remove-planner-course" data-course="${id}" aria-label="Remove ${c.code}">×</button><strong>${c.code}</strong><span>${c.name}</span><small>${formatPlannerTime(interval[0])}–${formatPlannerTime(interval[1])}</small></article>`);
  }).join(''):'<p class="planner-calendar-empty">Drop a course here or use Add to Schedule</p>';
  holder.querySelectorAll('.planner-calendar-event').forEach(el=>{el.addEventListener('click',e=>{if(!e.target.closest('button'))openDrawer(el.dataset.course)});el.addEventListener('keydown',e=>{if(e.key==='Enter')openDrawer(el.dataset.course)});el.addEventListener('contextmenu',e=>openCalendarContextMenu(e,el.dataset.course))});
  renderPlannerCourseSidebar();renderPlannerSearch();renderSuggestions();
}
function addPlannerCourse(id){if(!courses[id]||plannerCourses.has(id))return;plannerCourses.add(id);renderManualSchedule();appendChatMessage('assistant',`${courses[id].code} is now on your calendar. I’ll use the updated plan for your next request.`);showToast(`${courses[id].code} added`,'It now appears in your weekly calendar.')}
function renderSuggestions(){
  const context=document.getElementById('planner-chat-context');if(context)context.textContent=`Planning with ${plannerCourses.size} selected course${plannerCourses.size===1?'':'s'}`;
}
function setAiPanel(open){
  const button=document.getElementById('syllo-ai-toggle'),panel=document.getElementById('syllo-ai-panel'),layout=document.querySelector('.planner-layout');if(!button||!panel||!layout)return;
  button.setAttribute('aria-expanded',String(open));button.querySelector('.syllo-ai-label').textContent=open?'Close AI':'Syllo AI';
  panel.classList.toggle('is-collapsed',!open);panel.setAttribute('aria-hidden',String(!open));panel.inert=!open;layout.classList.toggle('ai-closed',!open);
}
function appendChatMessage(role,content,actions=''){
  const chat=document.getElementById('planner-chat');if(!chat)return;
  const message=document.createElement('div');message.className=`chat-message ${role}`;
  const label=document.createElement('span');label.textContent=role==='user'?'You':'Syllo';
  const body=document.createElement('p');body.textContent=content;message.append(label,body);
  if(actions){const actionHolder=document.createElement('div');actionHolder.className='chat-message-actions';actionHolder.innerHTML=actions;message.append(actionHolder)}
  chat.append(message);chat.scrollTop=chat.scrollHeight;
}
function handlePlannerPrompt(raw){
  const prompt=raw.trim();if(!prompt)return;appendChatMessage('user',prompt);
  const lower=prompt.toLowerCase(),available=Object.keys(courses).filter(id=>!plannerCourses.has(id));
  if(lower.includes('friday')||lower.includes('day off')||lower.includes('early')||lower.includes('morning')){
    appendChatMessage('assistant','Your current demo sections already keep Friday free. I can also preview a compact version that avoids very early starts.','<button class="button primary" data-action="preview-alternative">Preview option</button>');return;
  }
  let id=available[0];
  if(lower.includes('workload'))id=available.sort((a,b)=>Number(courses[a].difficulty.split(' ')[0])-Number(courses[b].difficulty.split(' ')[0]))[0];
  if(id){const c=courses[id];appendChatMessage('assistant',`${c.code} · ${c.name} is the closest match in the available demo data. It supports ${c.requirement} and meets ${c.days} at ${c.time}. Prerequisites still need verification.`,`<button class="button primary" data-action="preview-suggestion" data-course="${id}">Preview change</button>`)}
  else appendChatMessage('assistant','Every course in the demo catalog is already on your calendar. Try asking me to review a day, time window, or workload balance.');
}

function renderRequirementDetail(key){
  const detail=requirementDetails[key],holder=document.getElementById('requirement-detail');if(!holder||!detail)return;
  document.querySelectorAll('[data-requirement]').forEach(row=>row.classList.toggle('active',row.dataset.requirement===key));
  holder.innerHTML=`<span class="requirement-status">${detail.status}</span><h3>${detail.title}</h3><p>${detail.copy}</p><div class="requirement-course-list">${detail.courses.length?detail.courses.map(id=>`<button data-course="${id}" class="requirement-course"><strong>${courses[id].code}</strong><span>${courses[id].name}</span><small>${courses[id].credits} credits · ${courses[id].requirement}</small></button>`).join(''):'<div class="empty-state">Course-level records are not available for this completed requirement.</div>'}</div>`;
  holder.querySelectorAll('[data-course]').forEach(button=>button.addEventListener('click',()=>openDrawer(button.dataset.course)));
}
function allDegreeCourseIds(){return semesterOrder.flatMap(term=>degreeSemesters[term])}
function renderElectives(){
  const holder=document.getElementById('elective-results');if(!holder)return;const id='phil114',c=courses[id],added=allDegreeCourseIds().includes(id);
  holder.innerHTML=`<article><div><span>${c.code}</span><strong>${c.name}</strong><small>${c.credits} credits · ${c.requirement} · Prerequisites unavailable</small></div><button class="button ${added?'quiet':'primary'}" data-action="add-degree-elective" data-course="${id}" ${added?'disabled':''}>${added?'Added to plan':'Add to Spring 2027'}</button></article>`;
}
function renderDegreeSemesters(){
  const holder=document.getElementById('semester-columns');if(!holder)return;
  holder.innerHTML=semesterOrder.map((term,termIndex)=>{const ids=degreeSemesters[term],credits=ids.reduce((sum,id)=>sum+courses[id].credits,0);return `<section class="semester-column"><div class="semester-column-head"><strong>${semesterLabels[term]}</strong><span>${credits} credits</span></div><div>${ids.length?ids.map(id=>`<article class="semester-course"><div><strong>${courses[id].code}</strong><span>${courses[id].name}</span></div><div><button data-action="move-degree-course" data-course="${id}" data-term="${term}" data-direction="-1" ${termIndex===0?'disabled':''} aria-label="Move ${courses[id].code} earlier">‹</button><button data-action="move-degree-course" data-course="${id}" data-term="${term}" data-direction="1" ${termIndex===semesterOrder.length-1?'disabled':''} aria-label="Move ${courses[id].code} later">›</button></div></article>`).join(''):'<p class="semester-empty">No demo courses planned</p>'}</div></section>`}).join('');
  const planned=allDegreeCourseIds().reduce((sum,id)=>sum+courses[id].credits,0),remaining=Math.max(0,120-82-planned),percent=Math.min(100,Math.round((82+planned)/120*100));
  document.getElementById('degree-planned-credits').textContent=planned;document.getElementById('degree-planned-label').textContent=`${planned} planned`;document.getElementById('degree-remaining-label').textContent=`${remaining} remaining`;document.getElementById('degree-progress-fill').style.width=`${percent}%`;document.getElementById('degree-grad-date').textContent=degreeSemesters['fall-2028'].length?'December 2028':'May 2028';renderElectives();
}

function openDrawer(id){
  const c=courses[id];
  const drawer=document.getElementById('detail-drawer');
  document.getElementById('drawer-pill').textContent=c.code;
  const lock=document.getElementById('drawer-lock');
  lock.dataset.course=id; lock.classList.toggle('active',locked.has(id)); lock.textContent=locked.has(id)?'● Locked':'○ Lock course';
  document.getElementById('drawer-content').innerHTML=`
    <h2>${c.name}</h2><p class="subtitle">${c.code} · Demo section ${sectionNumber(c)}</p>
    <div class="detail-metrics"><div><small>CREDITS</small><strong>${c.credits}</strong></div><div><small>MEETS</small><strong>${c.days}</strong></div><div><small>TIME</small><strong>${c.time}</strong></div></div>
    <section class="detail-section"><h3>Course details</h3><div class="info-row"><span>Description</span><strong>Not available in demo data</strong></div><div class="info-row"><span>Instructor</span><strong>${instructorName(c)}</strong></div><div class="info-row"><span>Prerequisites</span><strong>Not available in demo data</strong></div><div class="info-row"><span>Meeting time</span><strong>${c.days} · ${c.time}</strong></div><div class="info-row"><span>Live availability</span><strong>Not provided</strong></div><span class="requirement-tag">Requirement area: ${c.requirement}</span></section>
    <section class="detail-section"><h3>Demo planning estimates</h3><div class="info-row"><span>Course difficulty</span><strong>${c.difficulty}</strong></div><div class="info-row"><span>Weekly workload</span><strong>${c.workload}</strong></div><div class="info-row"><span>Instructor rating</span><strong>${c.rating} / 5</strong></div><p class="sample-note">These values are simulated for interface demonstration and are not live university or registration data.</p></section>`;
  drawer.classList.add('open'); drawer.setAttribute('aria-hidden','false'); document.getElementById('drawer-backdrop').classList.remove('hidden');
}

function closeDrawer(){document.getElementById('detail-drawer').classList.remove('open');document.getElementById('detail-drawer').setAttribute('aria-hidden','true');document.getElementById('drawer-backdrop').classList.add('hidden')}
function showToast(title='Plan saved',text='You can return and edit it anytime.'){const t=document.getElementById('toast');t.querySelector('strong').textContent=title;t.querySelector('small').textContent=text;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2800)}

document.addEventListener('click',e=>{
  const a=e.target.closest('[data-action]');
  if(a){
    const action=a.dataset.action;
    if(action==='login'){
      a.disabled=true;
      a.setAttribute('aria-busy','true');
      a.querySelector('span').textContent='Loading your Lehigh profile…';
      setTimeout(()=>{showScreen('features');showToast('Lehigh profile loaded','Your connected planning tools are ready.')},650);
    }
    if(action==='open-schedules')showScreen('planner');
    if(action==='open-degree')showScreen('requirements');
    if(action==='open-advisor')showScreen('advisor');
    if(action==='back-features')showScreen('features');
    if(action==='toggle-ai')setAiPanel(a.getAttribute('aria-expanded')!=='true');
    if(action==='add-planner-course')addPlannerCourse(a.dataset.course);
    if(action==='remove-planner-course'){const removed=courses[a.dataset.course];plannerCourses.delete(a.dataset.course);renderManualSchedule();appendChatMessage('assistant',`${removed.code} was removed. Your calendar and planning context are updated.`)}
    if(action==='context-view-course'&&contextCalendarCourse){const id=contextCalendarCourse;closeCalendarContextMenu();openDrawer(id)}
    if(action==='context-remove-course'&&contextCalendarCourse){const id=contextCalendarCourse,c=courses[id];plannerCourses.delete(id);closeCalendarContextMenu();renderManualSchedule();appendChatMessage('assistant',`${c.code} was removed. Your calendar and planning context are updated.`);showToast(`${c.code} removed`,'The course was removed from this plan.')}
    if(action==='quick-prompt')handlePlannerPrompt(a.dataset.prompt);
    if(action==='preview-suggestion'){
      plannerPreviewId=a.dataset.course;const c=courses[plannerPreviewId];
      appendChatMessage('assistant',`Preview: add ${c.code} · ${c.name} (${c.credits} credits) on ${c.days} at ${c.time}. Your calendar will not change until you apply it.`,`<button class="button primary" data-action="accept-suggestion" data-course="${plannerPreviewId}">Apply to calendar</button>`);
    }
    if(action==='preview-alternative'){
      appendChatMessage('assistant','Preview: keep CSE 241 and MATH 231, then add PHIL 114 and CSE 252. This keeps Friday free using the available demo meeting times. Prerequisites still need verification.','<button class="button primary" data-action="accept-alternative">Apply this option</button>');
    }
    if(action==='accept-alternative'){plannerCourses=new Set(['cse241','math231','phil114','cse252']);renderManualSchedule();appendChatMessage('assistant','The option is applied. Your Monday–Friday calendar now shows the updated plan.');showToast('Calendar updated','The previewed option was applied.')}
    if(action==='accept-suggestion')addPlannerCourse(a.dataset.course);
    if(action==='move-degree-course'){
      const current=a.dataset.term,index=semesterOrder.indexOf(current),next=index+Number(a.dataset.direction),id=a.dataset.course;
      if(next>=0&&next<semesterOrder.length){degreeSemesters[current]=degreeSemesters[current].filter(courseId=>courseId!==id);degreeSemesters[semesterOrder[next]].push(id);renderDegreeSemesters()}
    }
    if(action==='add-degree-elective'){
      const id=a.dataset.course;if(!allDegreeCourseIds().includes(id)){degreeSemesters['spring-2027'].push(id);renderDegreeSemesters();showToast(`${courses[id].code} added`,'Degree progress and credit totals were updated.')}
    }
    if(action==='request-changes')showToast('Changes requested','Your feedback has been shared with the student.');
    if(action==='approve-plan')showToast('Plan approved','The student can now move forward with registration.');
    if(action==='home'||action==='back-welcome')showScreen('welcome');
    if(action==='start'){showScreen('onboarding');setOnboardingStep(1)}
    if(action==='demo'||action==='save-plan'){if(action==='demo'){showScreen('workspace');renderCourses();renderCalendar()}else showToast()}
    if(action==='next-onboarding')setOnboardingStep(onboardingStep+1);
    if(action==='previous-onboarding'){if(document.querySelector('[data-screen="mode"]').classList.contains('active')){showScreen('onboarding');setOnboardingStep(3)}else setOnboardingStep(onboardingStep-1)}
    if(action==='choose-mode')showScreen('mode');
    if(action==='close-drawer')closeDrawer();
    if(action==='add-course')showToast('Course search opened','Search and filters are ready for the next prototype step.');
  }
  const mode=e.target.closest('[data-mode]'); if(mode){showScreen('workspace');renderCourses();renderCalendar();showToast(mode.dataset.mode==='ai'?'3 schedules generated':'Manual builder ready',mode.dataset.mode==='ai'?'All required constraints were preserved.':'Search courses and add sections to your week.')}
  const tab=e.target.closest('[data-schedule]'); if(tab){activeSchedule=tab.dataset.schedule;document.querySelectorAll('[data-schedule]').forEach(t=>t.classList.toggle('active',t===tab));renderCalendar();const score={balanced:96,focused:91,compact:87}[activeSchedule];document.querySelector('.match-ring span').textContent=score;document.querySelector('.match-ring').style.background=`conic-gradient(var(--green) ${score}%,#e4e9e6 0)`}
  const requirement=e.target.closest('[data-requirement]');if(requirement)renderRequirementDetail(requirement.dataset.requirement);
});

navLinks.forEach(n=>n.addEventListener('click',()=>{if(n.dataset.nav==='requirements')showScreen('requirements');else {showScreen('workspace');renderCourses();renderCalendar()}}));
document.getElementById('drawer-backdrop').addEventListener('click',closeDrawer);
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeDrawer();setCourseSearchOpen(false);closeCalendarContextMenu()}});
document.getElementById('drawer-lock').addEventListener('click',e=>{const id=e.currentTarget.dataset.course;if(locked.has(id))locked.delete(id);else locked.add(id);e.currentTarget.classList.toggle('active',locked.has(id));e.currentTarget.textContent=locked.has(id)?'● Locked':'○ Lock course';renderCourses();renderCalendar();showToast(locked.has(id)?'Course locked':'Course unlocked',locked.has(id)?'AI will preserve this course when regenerating.':'This course can now change with the schedule.')});

const upload=document.getElementById('transcript-input'), zone=document.getElementById('upload-zone'), uploadContinue=document.getElementById('upload-continue');
function fileLoaded(name='transcript.pdf'){zone.classList.add('loaded');zone.querySelector('strong').textContent='Transcript ready';zone.querySelector('span:last-child').textContent=name+' · 24 courses identified';uploadContinue.disabled=false}
upload.addEventListener('change',()=>{if(upload.files[0])fileLoaded(upload.files[0].name)});
['dragenter','dragover'].forEach(type=>zone.addEventListener(type,e=>{e.preventDefault();zone.classList.add('dragging')}));
['dragleave','drop'].forEach(type=>zone.addEventListener(type,e=>{e.preventDefault();zone.classList.remove('dragging');if(type==='drop')fileLoaded(e.dataTransfer.files[0]?.name)}));
document.querySelectorAll('.day-toggles button').forEach(b=>b.addEventListener('click',()=>b.classList.toggle('selected')));
const courseSearchInput=document.getElementById('course-search');
courseSearchInput.addEventListener('focus',()=>setCourseSearchOpen(true));
courseSearchInput.addEventListener('input',e=>{renderPlannerSearch(e.target.value);setCourseSearchOpen(true)});
document.addEventListener('pointerdown',e=>{if(!e.target.closest('#course-search-area'))setCourseSearchOpen(false);if(!e.target.closest('#calendar-context-menu'))closeCalendarContextMenu()});
document.getElementById('planner-chat-form').addEventListener('submit',e=>{e.preventDefault();const input=document.getElementById('planner-chat-input'),value=input.value;input.value='';handlePlannerPrompt(value)});
document.getElementById('elective-interest').addEventListener('change',()=>{renderElectives();showToast('Electives updated','Showing matches from the available demo catalog.')});
document.addEventListener('dragstart',e=>{const source=e.target.closest('[data-drag-course]');if(source)e.dataTransfer.setData('text/plain',source.dataset.dragCourse)});
const manualDrop=document.getElementById('planner-week-calendar');
manualDrop.addEventListener('dragover',e=>{e.preventDefault();manualDrop.classList.add('dragging')});
manualDrop.addEventListener('dragleave',()=>manualDrop.classList.remove('dragging'));
manualDrop.addEventListener('drop',e=>{e.preventDefault();manualDrop.classList.remove('dragging');addPlannerCourse(e.dataTransfer.getData('text/plain'));setCourseSearchOpen(false)});
renderCourses();renderCalendar();renderPlannerSearch();renderManualSchedule();renderRequirementDetail('general');renderElectives();renderDegreeSemesters();
